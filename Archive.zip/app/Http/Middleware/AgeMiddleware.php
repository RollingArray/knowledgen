<?php

namespace App\Http\Middleware;

use Closure;

class AgeMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        // dd($request->route('age'));
        if ($request->route('age') <= 18) {
            return response()->json(['error' => 'Unauthorized'], 401, ['X-Header-One' => 'Header Value']);
        }
        
        
        // if ($request->route('name') != 'Ranjoy') {
        //     return 'Not Ranjoy';
        // }

        


        return $next($request);
    }
}

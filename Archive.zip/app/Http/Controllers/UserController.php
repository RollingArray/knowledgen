<?php

namespace App\Http\Controllers;

use App\Jobs\SendEmailJob;
use App\Mail\NewUserRegister;
use App\Models\User;
use Illuminate\Contracts\Queue\Queue;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

// class PostRequest extends Request
// {
//     // public function rules()
//     // {
//     //     return [
//     //         'firstName' => 'required|unique:tbl_users',
//     //         'lastName' => 'required',
//     //         'email' => 'required|unique:tbl_users'
//     //     ];
//     // }
// }

class UserController extends Controller
{

    /**
     * 
     */
    public function __construct()
    {
        //
    }

    // public function toArrayCamel()
    // {
    //     $array = json_decode('{"firstName":"Ranjoy","lastName":"Sen","email":"r@g.com"}');

    //     foreach($array as $key => $value)
    //     {
    //         $converted = Str::of($key)->snake();
    //         echo $converted;
    //         $return[$converted] = $value;
    //     }

    //     //echo json_encode($return);

    //     return $return;
    // }


    /**
     * register
     *
     * @param  mixed $request
     * @return void
     */
    public function register(Request $request)
    {
        //creating a validator
        $validator = Validator::make($request->all(), [
            'user_first_name' => 'required',
            'user_last_name' => 'required',
            'user_email' => 'required|unique:tbl_users'
        ]);

        //if validation fails 
        if ($validator->fails()) {
            return response(
                array(
                    'error' => true,
                    'message' => $validator->errors()->all()
                ),
                400
            );
        }

        //creating a new user
        $user = new User();

        //adding values to the users
        $user->user_id = uniqid();
        $user->user_first_name = $request->input('user_first_name');
        $user->user_last_name = $request->input('user_last_name');
        $user->user_email = $request->input('user_email');
        $user->user_verification_code = bin2hex(openssl_random_pseudo_bytes(4));

        //saving the user to database
        $user->save();

        //unsetting the password so that it will not be returned 
        unset($user->verification_code);

        $detail = array(
            'email' => $user->user_email,
            'title' =>  'C2 - New user registration',
            'userVerificationCode' => $user->user_verification_code
        );

        try {
            dispatch(new SendEmailJob($detail));
            //Mail::to($detail['email'])->send(new NewUserRegister($detail));

        } catch (\Exception $th) {
            //throw $th;
            echo $th;
        }

        //returning the registered user 
        return array(
            'error' => false,
            'data' => $user
        );
    }

    public function sendEmail(Request $request)
    {
        $detail = array(
            'email' => 'code@rollingarray.co.in',
            'title' =>  'Test title',
            'body' => 'Test body'
        );

        try {
            //dispatch(new SendEmailJob($detail));
            Mail::to($detail['email'])->send(new NewUserRegister($detail));

        } catch (\Exception $th) {
            //throw $th;
            echo $th;
        }

        //returning the registered user 
        return array(
            'error' => false,
            'data' => 'sent'
        );
    }
}

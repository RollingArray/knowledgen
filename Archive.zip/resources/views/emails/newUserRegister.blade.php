<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>

<body>
	<div class="">
		<div class="aHl"></div>
		<div id=":19g" tabindex="-1"></div>
		<div id=":195" class="ii gt">
			<div id=":194" class="a3s aXjCH ">
				<div style="font-family:roboto,sans-serif;border:1px solid #e0e0e0;background-color:white;max-width:600px;margin:0 auto">
					<div style="background-color:#323433;padding:24px 0"><img style="margin:auto;display:block;" src="https://c2.api.rollingarray.co.in/img/app_email_header.png" class="CToWUd"></div>
					<table style="width:100%;background-color:#ffa000" cellpadding="0" cellspacing="0">
						<tbody>
							<tr>
								<td style="padding:24px">
									<div style="font-size:20px;line-height:24px;color:#323433">{{$details['title']}}</div>
								</td>
							</tr>
							<tr></tr>
						</tbody>
					</table>
					<div style="margin-bottom:24px;padding:24px 24px 0 24px">
						<table style="font-family:Helvetica,Arial,sans-serif;font-size:14px;margin:0;padding:0" cellpadding="0" cellspacing="0" width="100%">
							<tbody>
								<tr style="font-family:Helvetica,Arial,sans-serif;font-size:14px;margin:0;padding:0">
									<td style="font-family:Helvetica,Arial,sans-serif;font-size:12px;vertical-align:top;margin:0;padding:0 0 0px;float:right" valign="top">
										date
									</td>
								</tr>
								<tr style="font-family:Helvetica,Arial,sans-serif;font-size:14px;margin:0;padding:0">
									<td style="font-family:Helvetica,Arial,sans-serif;font-size:14px;vertical-align:top;margin:0;padding:0 0 20px" valign="top">
										Dear <strong style="font-family:Helvetica,Arial,sans-serif;font-size:14px;margin:0;padding:0">{{$details['userVerificationCode']}}
										</strong>
									</td>
								</tr>
								<tr style="font-family:Helvetica,Arial,sans-serif;font-size:14px;margin:0;padding:0">
									<td style="font-family:Helvetica,Arial,sans-serif;font-size:14px;vertical-align:top;margin:0;padding:0 0 20px" valign="top">

										<br><br>
									</td>
								</tr>
								<tr style="font-family:Helvetica,Arial,sans-serif;font-size:14px;margin:0;padding:0">
									<td style="font-family:Helvetica,Arial,sans-serif;font-size:14px;vertical-align:top;margin:0;padding:0 0 20px" valign="top"><b>
											Regards<br>
											Team </b>
									</td>
								</tr>
								<tr style="font-family:Helvetica,Arial,sans-serif;font-size:14px;margin:0;padding:0">
									<td style="font-family:Helvetica,Arial,sans-serif;font-size:14px;vertical-align:top;margin:0;padding:0 0 20px;font-style:italic" valign="top">

									</td>
								</tr>
							</tbody>
						</table>
					</div>
					<div style="background-color:#d7d8da;padding:20px">
						<table style="width:100%" cellpadding="0" cellspacing="0">
							<tbody>
								<tr>
									<td>
										<div style="font-family:Helvetica,Arial,sans-serif; font-size:20px;line-height:24px; text-align: center; padding:20px">
											Connect from your favorite space
										</div>
									</td>
								</tr>
								<tr>
									<td>
										<a href="https://c2.rollingarray.co.in" target="_blank">
											<img style="height:60px; display: block; margin-left: auto; margin-right: auto;" src="https://c2.api.rollingarray.co.in/img/devices.png" class="CToWUd">
										</a>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
					<div style="background-color:#e0e0e0;height:1px;width:100%"></div>
					<div style="background-color:#e0e0e0;height:1px;width:100%"></div>
					<div style="background-color:#eceff1;padding:24px;font-size:12px;line-height:16px">
						<div>You are receiving this notification because you have registered with <span style="color:#56C2E1"> <a style="text-decoration:none;color:#039be5" href="https://c2.rollingarray.co.in/" target="_blank"></a></span></div>
						<div style="margin-top:24px">Thanks for using !</div>
					</div>
					<div style="background-color:#323433;padding:34px">
						<table style="width:100%" cellpadding="0" cellspacing="0">
							<tbody>
								<tr>
									<td>
										<a href="https://rollingarray.co.in/" target="_blank">
											<img style="height:34px;max-height:34px;min-height:34px" src="https://rollingarray.co.in/images/ra_brand_icon_email.png" class="CToWUd">
										</a>
									</td>
									<td>
										<div style="font-size:10px;line-height:14px;font-weight:400;text-align:right"><a style="color:#d6dde1;text-decoration:none">&copy; RollingArray<br>Bangalore, India. </a></div>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<div class="yj6qo"></div>
		</div>
		<div id=":19l" class="ii gt" style="display:none">
			<div id=":19k" class="a3s aXjCH undefined"></div>
		</div>
		<div class="hi"></div>
	</div>
</body>

</html>
<?php

/** @var \Laravel\Lumen\Routing\Router $router */

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

$router->get('/', function () use ($router) {
    return $router->app->version();
});

// $router->group(['prefix' => 'api/v1'], function () use ($router) {
//     $router->post(
//         'register', 
//         [
//             'uses' => 'UserController@register'
//         ]
//     );
// });

$router->group(['prefix' => 'api/v1'], function () use ($router) {
    
    $router->get('/users[/{name}]', function ($name = null) {
        return $name;
    });

    $router->get('ip/{address:[0-9]+}', function ($address) {
        return $address;
    });


    // ['middleware' => 'age', function ($age) {
    //     return $age;
    // }]

    // $router->group(['prefix' => 'register/{age}'], function () use ($router) {
    //     $router->get('detail', ['middleware' => 'age', function ($age) {
    //         return $age;
    //     }]);
    // });

    $router->post('register/detail', 
        [
            // 'middleware' => 'age', 
            'uses' => 'UserController@register'
        ]
    );

    $router->post('email', 
        [
            // 'middleware' => 'age', 
            'uses' => 'UserController@sendEmail'
        ]
    );
});